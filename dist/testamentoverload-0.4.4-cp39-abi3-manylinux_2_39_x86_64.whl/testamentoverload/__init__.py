from testamentoverload._core import hello_from_bin
from .model import LinearRegression

def hello() -> str:
    return hello_from_bin()
